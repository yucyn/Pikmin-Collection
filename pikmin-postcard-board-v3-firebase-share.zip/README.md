# Pikmin Postcard Board V3 — Firebase + 單一卡片分享

## 新增功能

1. 所有人看到同一份卡片資料
2. 所有人看到同一份愛心數
3. 不同用戶可各自點愛心，愛心數累加
4. 可分享單一卡片頁
5. 保留預覽模式，預覽模式不可刪除

## 必填：Firebase 設定

請打開：

js/firebaseConfig.js

把 Firebase Console 的 Web App config 貼上：

window.PIKMIN_FIREBASE_CONFIG = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "..."
};

## Firebase Firestore 建議資料庫

Cloud Firestore

Collection 名稱預設：

pikmin_postcards

可在 js/firebaseConfig.js 修改：

window.PIKMIN_FIREBASE_COLLECTION = "pikmin_postcards";

## 單一卡片分享

每張卡片有「分享」按鈕。

分享格式：

index.html?mode=preview&card=卡片ID

部署到 Vercel 後會變成：

https://你的網站.vercel.app/?mode=preview&card=卡片ID

## 開發測試

如果 Firebase config 還沒填，系統會自動退回 localStorage 測試模式。
